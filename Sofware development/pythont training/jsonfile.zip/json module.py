import json

#storing data in json file
#this is the data to be stored in json file
data={
    'NAMES':['chidalu','philip','fortune'],
    'AGE':[14,12,13],
    'CLASS':['SS1','SS2','SS3']
}; #python dictionary definition

#storing file in json format
file=open('data.json','w'); #open file for writing
json.dump(data,file); #dump data in file

#retrieving data from json
file=open('data.json','r'); #open file for reading
data=json.load(file); #read json file
print(data);